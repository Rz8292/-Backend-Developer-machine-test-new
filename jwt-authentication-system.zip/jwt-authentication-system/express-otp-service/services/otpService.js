const crypto = require('crypto');
const nodemailer = require('nodemailer');
const { pool } = require('../db');

const ttlMinutes = Number(process.env.OTP_TTL_MINUTES || 5);
const maxAttempts = Number(process.env.OTP_MAX_ATTEMPTS || 5);

function hashOtp(otp) {
  return crypto.createHash('sha256').update(otp).digest('hex');
}

async function sendOtp(email) {
  const otp = String(crypto.randomInt(100000, 1000000));
  const expiresAt = new Date(Date.now() + ttlMinutes * 60 * 1000);
  await pool.query(
    `INSERT INTO otp_codes(email, otp_hash, expires_at, attempts, created_at)
     VALUES($1,$2,$3,0,NOW())
     ON CONFLICT(email) DO UPDATE SET otp_hash=EXCLUDED.otp_hash,
       expires_at=EXCLUDED.expires_at, attempts=0, created_at=NOW()`,
    [email.toLowerCase(), hashOtp(otp), expiresAt]
  );

  const smtpHost = process.env.SMTP_HOST;
  if (smtpHost) {
    const transporter = nodemailer.createTransport({
      host: smtpHost,
      port: Number(process.env.SMTP_PORT || 587),
      secure: String(process.env.SMTP_SECURE).toLowerCase() === 'true',
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined
    });
    await transporter.sendMail({
      from: process.env.SMTP_FROM || 'no-reply@example.com',
      to: email,
      subject: 'Your account verification OTP',
      text: `Your verification OTP is ${otp}. It expires in ${ttlMinutes} minutes.`
    });
  } else {
    console.log(`[LOCAL DEVELOPMENT ONLY] OTP for ${email}: ${otp}`);
  }
}

async function verifyOtp(email, otp) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await client.query(
      'SELECT otp_hash, expires_at, attempts FROM otp_codes WHERE email=$1 FOR UPDATE',
      [email.toLowerCase()]
    );
    if (result.rowCount === 0) {
      await client.query('ROLLBACK');
      return false;
    }
    const record = result.rows[0];
    if (new Date(record.expires_at).getTime() <= Date.now() || record.attempts >= maxAttempts) {
      await client.query('DELETE FROM otp_codes WHERE email=$1', [email.toLowerCase()]);
      await client.query('COMMIT');
      return false;
    }
    const suppliedHash = hashOtp(otp);
    const valid = crypto.timingSafeEqual(Buffer.from(record.otp_hash, 'hex'), Buffer.from(suppliedHash, 'hex'));
    if (!valid) {
      await client.query('UPDATE otp_codes SET attempts=attempts+1 WHERE email=$1', [email.toLowerCase()]);
      await client.query('COMMIT');
      return false;
    }
    // Delete on success so the same OTP cannot be replayed.
    await client.query('DELETE FROM otp_codes WHERE email=$1', [email.toLowerCase()]);
    await client.query('COMMIT');
    return true;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

module.exports = { sendOtp, verifyOtp };
