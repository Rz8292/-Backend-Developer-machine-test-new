const express = require('express');
const { sendOtp, verifyOtp } = require('../services/otpService');
const internalAuth = require('../middleware/internalAuth');

const router = express.Router();
router.use(internalAuth);

router.post('/send', async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+$/.test(email) || !email.includes('_')) {
      return res.status(400).json({ message: 'A valid email containing @ and _ is required' });
    }
    await sendOtp(email);
    res.status(200).json({ message: 'OTP generated and dispatched' });
  } catch (error) { next(error); }
});

router.post('/verify', async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const otp = String(req.body.otp || '').trim();
    if (!email || !/^\d{6}$/.test(otp)) {
      return res.status(400).json({ message: 'Email and six-digit OTP are required' });
    }
    const verified = await verifyOtp(email, otp);
    res.status(200).json({ verified, message: verified ? 'OTP verified' : 'Invalid or expired OTP' });
  } catch (error) { next(error); }
});

module.exports = router;
