function internalAuth(req, res, next) {
  const expected = process.env.OTP_INTERNAL_API_KEY;
  const supplied = req.get('X-Internal-Api-Key');
  if (!expected || !supplied || supplied !== expected) {
    return res.status(401).json({ message: 'Unauthorized internal service request' });
  }
  next();
}
module.exports = internalAuth;
