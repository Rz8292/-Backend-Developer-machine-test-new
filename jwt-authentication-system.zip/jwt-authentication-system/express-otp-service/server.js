require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const { initializeDatabase } = require('./db');
const otpRoutes = require('./routes/otpRoutes');

const app = express();
app.use(helmet());
app.use(express.json({ limit: '10kb' }));

app.get('/health', (_req, res) => res.json({ status: 'UP', service: 'express-otp-service' }));
app.use('/internal/otp', otpRoutes);

app.use((err, _req, res, _next) => {
  console.error('OTP service error:', err.message);
  res.status(500).json({ message: 'OTP service failed' });
});

const port = Number(process.env.PORT || 3001);
initializeDatabase()
  .then(() => app.listen(port, () => console.log(`Express OTP service listening on ${port}`)))
  .catch(error => {
    console.error('Could not initialize OTP database:', error.message);
    process.exit(1);
  });
