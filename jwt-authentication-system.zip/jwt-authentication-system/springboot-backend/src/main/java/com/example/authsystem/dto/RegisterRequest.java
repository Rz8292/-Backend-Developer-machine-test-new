package com.example.authsystem.dto;

import jakarta.validation.constraints.*;

public record RegisterRequest(
    @NotBlank @Size(min=8,max=50) String username,
    @NotBlank @Email @Pattern(regexp="^(?=.{5,254}$)(?=.*@)(?=.*_).+$", message="Email must contain @ and _") String email,
    @NotBlank @Pattern(regexp="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,12}$",
        message="Password must be 8-12 characters and include uppercase, lowercase, number and special character") String password,
    String userType
) {}
