package com.example.authsystem.dto;
import jakarta.validation.constraints.*;
public record VerifyOtpRequest(@NotBlank @Email String email, @NotBlank @Pattern(regexp="\\d{6}") String otp) {}
