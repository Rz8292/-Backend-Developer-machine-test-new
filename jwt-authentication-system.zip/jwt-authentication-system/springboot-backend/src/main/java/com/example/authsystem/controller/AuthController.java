package com.example.authsystem.controller;

import com.example.authsystem.dto.*;
import com.example.authsystem.entity.AppUser;
import com.example.authsystem.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    public AuthController(AuthService auth){this.auth=auth;}
    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest body,HttpServletRequest request){
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("message",auth.register(body,request.getRemoteAddr())));
    }
    @PostMapping("/verify-otp")
    public ResponseEntity<?> verify(@Valid @RequestBody VerifyOtpRequest body){
        return ResponseEntity.ok(Map.of("message",auth.verifyOtp(body)));
    }
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest body){return ResponseEntity.ok(auth.login(body));}
    @GetMapping("/error")
    public ResponseEntity<?> error(){return ResponseEntity.status(401).body(Map.of("message","Login Failed"));}
    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestHeader("Authorization") String authorization){
        String token=authorization.substring(7);
        return ResponseEntity.ok(Map.of("message",auth.logout(token)));
    }
}
