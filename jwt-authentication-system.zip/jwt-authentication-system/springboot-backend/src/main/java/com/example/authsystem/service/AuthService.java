package com.example.authsystem.service;

import com.example.authsystem.dto.*;
import com.example.authsystem.entity.*;
import com.example.authsystem.repository.*;
import com.example.authsystem.security.JwtService;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.time.*;
import java.util.*;

@Service
public class AuthService {
    private final UserRepository users; private final RevokedTokenRepository revoked;
    private final PasswordEncoder encoder; private final OtpClient otp; private final JwtService jwt;
    private final CountryService countryService;
    public AuthService(UserRepository users,RevokedTokenRepository revoked,PasswordEncoder encoder,
        OtpClient otp,JwtService jwt,CountryService countryService){
        this.users=users;this.revoked=revoked;this.encoder=encoder;this.otp=otp;this.jwt=jwt;this.countryService=countryService;
    }
    @Transactional
    public String register(RegisterRequest request,String ip){
        String country=countryService.countryFor(ip);
        if(countryService.isBlocked(country)) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Sign-up is not allowed from your country");
        if(users.existsByEmail(request.email().toLowerCase())) throw new ResponseStatusException(HttpStatus.CONFLICT,"Email already registered");
        if(request.userType()!=null && !request.userType().isBlank() &&
            !request.userType().equalsIgnoreCase("STANDARD_USER") &&
            !request.userType().equalsIgnoreCase("Standard User"))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Public sign-up is available only for Standard User");
        AppUser user=new AppUser(request.username(),request.email().toLowerCase(),encoder.encode(request.password()),Role.STANDARD_USER,false);
        users.save(user);
        otp.send(user.getEmail());
        return "Registration received. Verify the OTP sent to your email to activate your account.";
    }
    @Transactional
    public String verifyOtp(VerifyOtpRequest request){
        AppUser user=users.findByEmail(request.email().toLowerCase())
            .orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"User not found"));
        if(user.isVerified()) return "Account is already verified";
        if(!otp.verify(user.getEmail(),request.otp()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid or expired OTP");
        user.setVerified(true); users.save(user);
        return "OTP verified successfully. Account activated.";
    }
    public Map<String,Object> login(LoginRequest request){
        AppUser user=users.findByEmail(request.email().toLowerCase()).orElse(null);
        if(user==null || !encoder.matches(request.password(),user.getPassword()))
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Login Failed");
        if(!user.isVerified()) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Please verify your email using OTP first");
        String token=jwt.generate(user);
        return Map.of("message","Login successful","token",token,"tokenType","Bearer",
            "expiresInSeconds",jwt.getExpirationMs()/1000,"username",user.getUsername(),"role",user.getRole().name());
    }
    public String logout(String token){
        Claims claims=jwt.parse(token);
        String jti=claims.getId();
        if(!revoked.existsById(jti)){
            revoked.save(new RevokedToken(jti,claims.getExpiration().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()));
        }
        return claims.get("username",String.class)+" Logged Out";
    }
    @Transactional
    public void createAdmin(CreateAdminRequest request){
        if(users.existsByEmail(request.email().toLowerCase())) throw new ResponseStatusException(HttpStatus.CONFLICT,"Email already registered");
        users.save(new AppUser(request.username(),request.email().toLowerCase(),encoder.encode(request.password()),Role.ADMINISTRATOR,true));
    }
}
