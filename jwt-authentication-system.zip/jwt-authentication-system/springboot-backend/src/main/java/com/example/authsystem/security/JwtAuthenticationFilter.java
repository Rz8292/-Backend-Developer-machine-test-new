package com.example.authsystem.security;

import com.example.authsystem.repository.RevokedTokenRepository;
import io.jsonwebtoken.Claims;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    private final JwtService jwt;
    private final CurrentUser currentUser;
    private final RevokedTokenRepository revoked;
    public JwtAuthenticationFilter(JwtService jwt,CurrentUser currentUser,RevokedTokenRepository revoked){
        this.jwt=jwt;this.currentUser=currentUser;this.revoked=revoked;
    }
    @Override protected void doFilterInternal(HttpServletRequest request,HttpServletResponse response,FilterChain chain)
        throws ServletException,IOException {
        String header=request.getHeader("Authorization");
        if(header!=null && header.startsWith("Bearer ") && SecurityContextHolder.getContext().getAuthentication()==null){
            try {
                Claims claims=jwt.parse(header.substring(7));
                String jti=claims.getId();
                if(jti!=null && !revoked.existsById(jti)){
                    UserDetails user=currentUser.loadUserByUsername(claims.getSubject());
                    if(user.isEnabled()){
                        var auth=new UsernamePasswordAuthenticationToken(user,null,user.getAuthorities());
                        auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                        SecurityContextHolder.getContext().setAuthentication(auth);
                    }
                }
            } catch (Exception ignored) {
                SecurityContextHolder.clearContext();
            }
        }
        chain.doFilter(request,response);
    }
}
