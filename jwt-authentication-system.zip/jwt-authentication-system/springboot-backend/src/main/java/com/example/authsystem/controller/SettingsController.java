package com.example.authsystem.controller;

import com.example.authsystem.dto.CreateAdminRequest;
import com.example.authsystem.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class SettingsController {
    private final AuthService auth;
    public SettingsController(AuthService auth){this.auth=auth;}
    @GetMapping("/settings")
    @PreAuthorize("hasRole('ADMINISTRATOR')")
    public Map<String,String> settings(){return Map.of("message","Administrator Settings Access Granted");}
    @PostMapping("/admin/users")
    @PreAuthorize("hasRole('ADMINISTRATOR')")
    public Map<String,String> createAdmin(@Valid @RequestBody CreateAdminRequest request){
        auth.createAdmin(request);return Map.of("message","Administrator created successfully");
    }
}
