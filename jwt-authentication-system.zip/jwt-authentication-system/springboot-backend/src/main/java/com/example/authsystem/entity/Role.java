package com.example.authsystem.entity;

public enum Role {
    STANDARD_USER,
    ADMINISTRATOR
}
