package com.example.authsystem.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "products")
public class Product {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 120)
    private String name;
    @Column(length = 1000)
    private String description;
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal price;
    @Column(nullable = false)
    private Integer stock;
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    protected Product() {}
    public Product(String name, String description, BigDecimal price, Integer stock, String createdBy) {
        this.name=name; this.description=description; this.price=price; this.stock=stock; this.createdBy=createdBy;
    }
    public Long getId(){return id;}
    public String getName(){return name;}
    public String getDescription(){return description;}
    public BigDecimal getPrice(){return price;}
    public Integer getStock(){return stock;}
    public String getCreatedBy(){return createdBy;}
    public LocalDateTime getCreatedAt(){return createdAt;}
    public LocalDateTime getUpdatedAt(){return updatedAt;}
    public void update(String name,String description,BigDecimal price,Integer stock){
        this.name=name; this.description=description; this.price=price; this.stock=stock; this.updatedAt=LocalDateTime.now();
    }
}
