package com.example.authsystem.config;

import com.example.authsystem.entity.*;
import com.example.authsystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class AdminBootstrap {
    @Bean CommandLineRunner bootstrapAdmin(UserRepository users,PasswordEncoder encoder,
        @Value("${BOOTSTRAP_ADMIN_USERNAME:}") String username,
        @Value("${BOOTSTRAP_ADMIN_EMAIL:}") String email,
        @Value("${BOOTSTRAP_ADMIN_PASSWORD:}") String password){
        return args -> {
            if(username.isBlank() || email.isBlank() || password.isBlank()) return;
            if(!username.matches(".{8,50}") || !email.matches("^(?=.{5,254}$)(?=.*@)(?=.*_).+$") ||
                !password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,12}$"))
                throw new IllegalStateException("Bootstrap admin credentials do not meet the signup policy");
            if(!users.existsByEmail(email.toLowerCase()))
                users.save(new AppUser(username,email.toLowerCase(),encoder.encode(password),Role.ADMINISTRATOR,true));
        };
    }
}
