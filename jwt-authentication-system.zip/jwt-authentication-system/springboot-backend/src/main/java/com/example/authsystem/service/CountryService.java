package com.example.authsystem.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.net.*;
import java.util.*;

@Service
public class CountryService {
    private final RestClient client;
    private final String devCountry;
    private final Set<String> blocked;
    public CountryService(RestClient client,
        @Value("${app.country.dev-country:IN}") String devCountry,
        @Value("${app.country.blocked-codes:SY,AF,IR,KP}") String blockedCodes){
        this.client=client;this.devCountry=devCountry;
        this.blocked=new HashSet<>(Arrays.asList(blockedCodes.toUpperCase().split(",")));
    }
    public String countryFor(String ip){
        try {
            InetAddress address=InetAddress.getByName(ip);
            if(address.isLoopbackAddress() || address.isSiteLocalAddress() || address.isLinkLocalAddress()) return devCountry;
            String country=client.get().uri("https://ipapi.co/{ip}/country/",ip).retrieve().body(String.class);
            if(country==null || country.isBlank()) throw new IllegalStateException("Country lookup returned empty response");
            return country.trim().toUpperCase();
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to determine sign-up country. Please try again later.");
        }
    }
    public boolean isBlocked(String country){return blocked.contains(country.toUpperCase());}
}
