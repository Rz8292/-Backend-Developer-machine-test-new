package com.example.authsystem.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="revoked_tokens")
public class RevokedToken {
    @Id
    private String jti;
    @Column(name="expires_at", nullable=false)
    private LocalDateTime expiresAt;
    @Column(name="revoked_at", nullable=false)
    private LocalDateTime revokedAt = LocalDateTime.now();
    protected RevokedToken() {}
    public RevokedToken(String jti, LocalDateTime expiresAt){this.jti=jti;this.expiresAt=expiresAt;}
}
