package com.example.authsystem.controller;

import com.example.authsystem.dto.ProductRequest;
import com.example.authsystem.entity.Product;
import com.example.authsystem.repository.ProductRepository;
import jakarta.validation.Valid;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.Map;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final ProductRepository products;
    public ProductController(ProductRepository products){this.products=products;}
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Product create(@Valid @RequestBody ProductRequest body,Authentication auth){
        return products.save(new Product(body.name(),body.description(),body.price(),body.stock(),auth.getName()));
    }
    @GetMapping
    public Page<Product> list(@RequestParam(defaultValue="0") int page,
        @RequestParam(defaultValue="10") int size,
        @RequestParam(defaultValue="id") String sortBy,
        @RequestParam(defaultValue="asc") String direction){
        if(page<0 || size<1 || size>100) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid pagination values");
        Sort sort=direction.equalsIgnoreCase("desc")?Sort.by(sortBy).descending():Sort.by(sortBy).ascending();
        return products.findAll(PageRequest.of(page,size,sort));
    }
    @GetMapping("/{id}")
    public Product get(@PathVariable Long id){return find(id);}
    @PutMapping("/{id}")
    public Product update(@PathVariable Long id,@Valid @RequestBody ProductRequest body){
        Product p=find(id);p.update(body.name(),body.description(),body.price(),body.stock());return products.save(p);
    }
    @DeleteMapping("/{id}")
    public Map<String,String> delete(@PathVariable Long id){products.delete(find(id));return Map.of("message","Product deleted successfully");}
    private Product find(Long id){return products.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Product not found"));}
}
