package com.example.authsystem.controller;

import com.example.authsystem.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
public class DashboardController {
    private final UserRepository users;
    public DashboardController(UserRepository users){this.users=users;}
    @GetMapping("/api/dashboard")
    public Map<String,String> dashboard(Authentication authentication){
        var user=users.findByEmail(authentication.getName()).orElseThrow();
        return Map.of("message","Welcome "+user.getUsername());
    }
}
