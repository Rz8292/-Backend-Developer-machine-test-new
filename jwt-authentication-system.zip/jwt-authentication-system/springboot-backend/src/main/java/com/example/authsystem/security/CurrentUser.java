package com.example.authsystem.security;

import com.example.authsystem.entity.AppUser;
import com.example.authsystem.repository.UserRepository;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class CurrentUser implements UserDetailsService {
    private final UserRepository users;
    public CurrentUser(UserRepository users){this.users=users;}
    @Override public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        AppUser u=users.findByEmail(email).orElseThrow(()->new UsernameNotFoundException("User not found"));
        return User.withUsername(u.getEmail()).password(u.getPassword())
            .roles(u.getRole().name()).disabled(!u.isVerified()).build();
    }
}
