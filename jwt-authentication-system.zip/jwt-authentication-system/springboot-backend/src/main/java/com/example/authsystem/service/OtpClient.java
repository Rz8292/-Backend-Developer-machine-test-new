package com.example.authsystem.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.util.Map;

@Service
public class OtpClient {
    private final RestClient client;
    private final String baseUrl, apiKey;
    public OtpClient(RestClient client,
        @Value("${app.otp.service-url}") String baseUrl,
        @Value("${app.otp.internal-api-key}") String apiKey){
        this.client=client;this.baseUrl=baseUrl;this.apiKey=apiKey;
    }
    public void send(String email){
        client.post().uri(baseUrl+"/internal/otp/send").header("X-Internal-Api-Key",apiKey)
            .contentType(MediaType.APPLICATION_JSON).body(Map.of("email",email)).retrieve().toBodilessEntity();
    }
    public boolean verify(String email,String otp){
        Map<?,?> result=client.post().uri(baseUrl+"/internal/otp/verify").header("X-Internal-Api-Key",apiKey)
            .contentType(MediaType.APPLICATION_JSON).body(Map.of("email",email,"otp",otp))
            .retrieve().body(Map.class);
        return result!=null && Boolean.TRUE.equals(result.get("verified"));
    }
}
