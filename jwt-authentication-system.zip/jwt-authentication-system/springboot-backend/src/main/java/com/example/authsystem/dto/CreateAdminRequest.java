package com.example.authsystem.dto;
import jakarta.validation.constraints.*;
public record CreateAdminRequest(
    @NotBlank @Size(min=8,max=50) String username,
    @NotBlank @Email @Pattern(regexp="^(?=.{5,254}$)(?=.*@)(?=.*_).+$") String email,
    @NotBlank @Pattern(regexp="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,12}$") String password
) {}
