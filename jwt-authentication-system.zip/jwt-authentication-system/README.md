# JWT Authentication System — Spring Boot + Express.js + PostgreSQL

This project uses only the requested application technologies:
- Java 17 + Spring Boot 3.4.5: main REST API, JWT security, roles, products, Swagger.
- Express.js: separate internal OTP service.
- PostgreSQL: users, products, revoked JWT IDs, OTP records.

No frontend framework is included. The assignment's Dashboard is provided as a protected REST endpoint.

## Architecture
Browser/Postman -> Spring Boot REST API -> PostgreSQL
                              |
                              +---- internal HTTP call ----> Express OTP service -> PostgreSQL

Spring Boot owns registration, login, JWT, authorization, products and dashboard.
Express owns OTP creation, expiry, attempt limits and verification. Both services use the same PostgreSQL database.
The OTP service is protected by an internal shared API key.

## Requirements
- Java 17+
- Maven 3.9+
- Node.js 20+
- PostgreSQL 14+
- Optional SMTP account for sending OTP email. Without SMTP configuration, OTP is printed in the Express terminal for local testing.

## 1. Create database
Run in PostgreSQL:
```sql
CREATE DATABASE jwt_auth_db;
```
The Spring Boot JPA configuration creates/updates its tables. Express creates `otp_codes` on startup.
You can also run `database/schema.sql` manually.

## 2. Configure PostgreSQL
Set environment variables, or edit `springboot-backend/src/main/resources/application.yml`:
```bash
export DB_URL=jdbc:postgresql://localhost:5432/jwt_auth_db
export DB_USERNAME=postgres
export DB_PASSWORD=your_postgres_password
export JWT_SECRET=VGhpc0lzQURlbW9Pbkx5U2VjcmV0S2V5Rm9ySldUU2lnbmluZ0FuZEVuY3J5cHRpb24=
export OTP_SERVICE_URL=http://localhost:3001
export OTP_INTERNAL_API_KEY=change-this-internal-key
export APP_DEV_COUNTRY=IN
```
The example JWT secret is for local development only. Generate a unique Base64 secret for real use:
`openssl rand -base64 64`

## 3. Start Express OTP service
```bash
cd express-otp-service
cp .env.example .env
# Edit .env with your PostgreSQL credentials and same OTP_INTERNAL_API_KEY
npm install
npm start
```
Express runs on `http://localhost:3001`.
If SMTP is not configured, look at the Express terminal for the six-digit OTP. Do not use console OTP logging in production.

## 4. Start Spring Boot
In another terminal:
```bash
cd springboot-backend
mvn spring-boot:run
```
Spring Boot runs on `http://localhost:8080`.
Swagger UI: `http://localhost:8080/swagger-ui.html`
OpenAPI JSON: `http://localhost:8080/v3/api-docs`

## 5. Create a Standard User
POST `http://localhost:8080/api/auth/register`
```json
{
  "username": "razique01",
  "email": "razique_test@example.com",
  "password": "Password@1",
  "userType": "STANDARD_USER"
}
```
Important: The assignment requires the email to contain both `@` and `_`. Use an email such as `razique_test@example.com`.
Registration sends an OTP. In local mode it appears in the Express terminal.

POST `http://localhost:8080/api/auth/verify-otp`
```json
{
  "email": "razique_test@example.com",
  "otp": "123456"
}
```

## 6. Login
POST `http://localhost:8080/api/auth/login`
```json
{
  "email": "razique_test@example.com",
  "password": "Password@1"
}
```
Copy `token` from the response. For protected APIs, set:
`Authorization: Bearer YOUR_JWT_TOKEN`

GET `/api/dashboard` -> `Welcome razique01`

## 7. Administrator account
Public registration cannot create an administrator because allowing users to select Administrator would let anyone grant themselves privileges.
Create the first admin using environment variables before starting Spring Boot:
```bash
export BOOTSTRAP_ADMIN_USERNAME=adminuser
export BOOTSTRAP_ADMIN_EMAIL=admin_user@example.com
export BOOTSTRAP_ADMIN_PASSWORD=Admin@123
```
The username must be 8–50 chars, password must meet the same policy, and email must contain `@` and `_`.
The admin account is created once if that email does not already exist. Login with this account and use its JWT.
GET `/api/settings` is available only to an Administrator.
POST `/api/admin/users` can be used by an Administrator to create another Administrator.

## 8. Product APIs (JWT required)
- POST `/api/products`
- GET `/api/products?page=0&size=10&sortBy=name&direction=asc`
- GET `/api/products/{id}`
- PUT `/api/products/{id}`
- DELETE `/api/products/{id}`

Example create:
```json
{
  "name": "Laptop",
  "description": "Business laptop",
  "price": 799.99,
  "stock": 15
}
```

## 9. Logout
POST `/api/auth/logout` with Bearer token.
The token's JWT ID (`jti`) is stored in `revoked_tokens`. The same token is rejected on subsequent protected requests, including Dashboard.

## API summary
| Method | Endpoint | Access |
|---|---|---|
| POST | `/api/auth/register` | Public |
| POST | `/api/auth/verify-otp` | Public |
| POST | `/api/auth/login` | Public |
| GET | `/api/auth/error` | Public |
| GET | `/api/dashboard` | Authenticated |
| GET | `/api/settings` | Administrator |
| POST | `/api/admin/users` | Administrator |
| POST | `/api/auth/logout` | Authenticated |
| POST | `/api/products` | Authenticated |
| GET | `/api/products` | Authenticated |
| GET | `/api/products/{id}` | Authenticated |
| PUT | `/api/products/{id}` | Authenticated |
| DELETE | `/api/products/{id}` | Authenticated |

## Country restriction
Spring Boot determines the request IP and looks up its country using `https://ipapi.co/{ip}/country/`. Syria (SY), Afghanistan (AF), Iran (IR), and North Korea (KP) are blocked by default. Add country codes to `app.country.blocked-codes` to extend the list.
For localhost/private IPs, `APP_DEV_COUNTRY` is used so you can test locally. In production, deploy behind a trusted reverse proxy and configure trusted forwarded headers carefully. Do not trust arbitrary client-supplied country headers.

## Security notes
- Passwords are BCrypt-hashed.
- JWTs are signed, have an expiration and unique `jti`.
- Logout revokes the `jti` in PostgreSQL.
- OTP is hashed in PostgreSQL, expires after five minutes and allows at most five attempts.
- Public sign-up is restricted to Standard User. Admin accounts are provisioned securely.
- All product endpoints require a valid, non-revoked JWT.
- Configure HTTPS, strong secrets, SMTP, database least-privilege credentials, rate limits and monitoring before production.
